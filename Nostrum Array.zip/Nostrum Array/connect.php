Welcome, <?php
   
echo $_GET['username']

?> 
<br><br>
Your password is <?php
   
echo $_GET['password']

?> 